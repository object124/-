print("hello world")
print("저는 프로그래머 입니다.")