print("hello world2")
print("헬로우 월드")