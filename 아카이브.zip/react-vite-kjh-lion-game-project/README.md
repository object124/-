### 1. 기본라우터 설정 및 다운로드

    "styled-components": "^6.1.12",
    "react-router-dom": "^6.26.0"

### 2. 브라우저 라우터 기본 설정
