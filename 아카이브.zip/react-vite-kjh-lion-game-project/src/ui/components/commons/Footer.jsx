import React from 'react'

const Footer = () => {
  return (
    <div>
      <footer className='text-center'>
        <hr />
        <p>© Company 2022-2023</p>
      </footer>
    </div>
  )
}

export default Footer
