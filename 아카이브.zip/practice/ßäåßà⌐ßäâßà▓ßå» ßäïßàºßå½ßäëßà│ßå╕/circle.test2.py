from circle import PI, ar_circle, ci_circle #circle.py모듈을 갖고옴 

print(PI)
print(ar_circle(4))
print(ci_circle(4))
