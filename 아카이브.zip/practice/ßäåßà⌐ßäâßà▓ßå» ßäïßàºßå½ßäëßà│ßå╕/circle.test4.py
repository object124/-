import circle as cc

r = float(input(" 반지름 입력 : "))
ar = cc.ar_circle(r)
print(" 원의 넓이 : ", ar)

