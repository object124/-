import circle #circle.py모듈을 갖고옴 

print(circle.PI)
print(circle.ar_circle(4))
print(circle.ci_circle(4))