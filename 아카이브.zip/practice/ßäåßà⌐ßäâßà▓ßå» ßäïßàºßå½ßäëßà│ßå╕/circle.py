PI=3.14

def ar_circle(r):
    return PI * r * r#원 넓이 계산
def ci_circle(r):
    return 2* PI * r #원 둘레 계산
    