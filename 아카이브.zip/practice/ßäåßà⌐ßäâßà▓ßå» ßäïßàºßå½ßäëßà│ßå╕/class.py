#예외 처리

#예외 처리에 대한 이해
#1. 파이썬에서 기본적인 예외 상황에 대한 처리는 예외가 발생하는 지점에서 죽는다. 이것도 하나의 메커니즘
#대신 죽은 이유 즉 에러 객체를 발생시켜준다.
#lst = [1,2,3]

#에러가 발생하는 상황
#lst[3]#IndexError: list index out of range


#예외 처리 목적 = 프로그램 안 죽게 하기 위해
#예외 처리 집어넣는 구문 정해져 있지 않고, 예외가 발생되리라고 생각되는 곳에 어디든 넣을 수 있음.
# try ~ except 처리


while True:
    
    try:
      age = int(input("나이를 입력하세요"))
      print(age)
      break
    except ValueError:
      print("입력이 잘못되었습니다")  

print("만나서 반가웠습니다")


def main():
          bread = 10 #10개의 빵
          try:
                  people = int(input("몇 명?"))
                  print("1인당 빵의 수:", bread / people)
                  print("맛있게 드세요")
          except ValueError:
                  print("입력이 잘못되었습니다")
          except ZeroDivisionError:
                  print("0으로 나눌 수 없습니다")

main()


#에러 메세지 확인

def main():
          bread = 10 #10개의 빵
          try:
                  people = int(input("몇 명?"))
                  print("1인당 빵의 수:", bread / people)
                  print("맛있게 드세요")
          except ValueError as msg:
                  print("입력이 잘못되었습니다")
                  print(msg) #오류 메세지 출력
          except ZeroDivisionError as msg:
                  print("0으로 나눌 수 없습니다")
                  print(ZeroDivisionError, msg)

          finally:
                  print("어쨌든 프로그램은 종료되었습니다")
main()