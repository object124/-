from circle import ci_circle as cc

def ci_circle(r):
    print("hello"+str(r))
print(cc(4))

ci_circle(4)