# bool형 
#True
#print(True)
#print(type(True))

#False
#print(False)
#print(type(False))


#cpu에게 묻는 것 -> 답을 bool형으로 준다

# 3 > 10 
# 3 + 10

###데이터 타입의 진정한 의미는
###메모리에 값을 올릴 때도 언어 차원에서 제공하는 데이터 타입 중 한개로 올라가고 = 개발자가 하나를 정해서 데이터를 올
###cpu가 답을 줄 때도 데이터 타입 중 하나를 잡아서 응답을 준다

# if 문 연습 조건이 맞으면 실행

#num = int(input("정수 입력"))

#if num > 0 : # True False가 리턴되는 구문
#    print("양수")

#if num != 0 : # ==같으면 #!=다르면
#    print("0이 아닙니다")


# if else 구문은 반드시 한개는 실행됨
#num = int(input("정수 입력"))

#if num > 0 : 
#    print("양수")
#else:
#    print("음수")



#def main():
#        pnum = input("스마트폰 번호 입력:")
#        if pnum.isdigit() and pnum.startswith("010"):
#            print("전화번호가 유효합니다.")
#        else:
#            print("전화번호가 유효하지 않습니다.")

#main()

#def main():
#        s = "tomato spaghetti"
#        if s. find("ghe") != -1:
#            print("있습니다 .")
#        else:
#            print("없습니다.")

#main()

#def main():
#        s = "tomato spaghetti"
#        if "ghe" in s:
#            print("있습니다 .")
#        else:
#            print("없습니다.")

#main()

