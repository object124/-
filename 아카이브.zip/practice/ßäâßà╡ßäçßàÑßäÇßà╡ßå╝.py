def add(a, b):
    return a + b 

print("디버깅")
print("디버깅")
print("디버깅")
print("디버깅")
print("디버깅")

add(5,6)