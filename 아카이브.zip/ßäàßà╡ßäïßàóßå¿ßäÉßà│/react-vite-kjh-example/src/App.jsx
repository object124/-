import { Hello } from './components/Hello'

function App() {
  return (
    <>
      <Hello></Hello>
    </>
  )
}

export default App
