import AxiosClient from '../pages/AxiosClient'
import AxiosGetPage from '../pages/AxiosGetPage'
import BoardPage from '../pages/BoardPage'
import BootStrapPage from '../pages/BootStrapPage'
import ConditionalPage from '../pages/ConditionalPage'
import CounterPage from '../pages/CounterPage'
import HelloPage from '../pages/HelloPage'
import HomePage from '../pages/HomePage'
import JSXPage from '../pages/JSXPage'
import ProfilePage from '../pages/ProfilePage'
import PropsPage from '../pages/PropsPage'
import UseEffectPage from '../pages/UseEffectPage'
import UseRef1Page from '../pages/UseRef1Page'
import UseRef2Page from '../pages/UseRef2Page'
import InputPage from '../pages/inputPage'
import GradeInputPage from '../pages/GradeInputPage'
import GradeInputPage2 from '../pages/GradeInputPage2'
import InlineStylePage from '../pages/cssPage/inlineStylePage'
import ClassNameUsePage from '../pages/cssPage/ClassnameUsePage'
import StyledComponentPage from '../pages/cssPage/StyledComponentPage'
import ContextNotUsePage from '../pages/ContextNotUsePage'
import ContextUsedPage from '../pages/ContextUsedPage'
import CounterContextPage from '../pages/CounterContext'
import CounterProvider from '../context/CounterProvider'

//React Routes, Route 사용시 배열로 관리하기
const routes = [
  {
    path: '/',
    element: <HomePage />,
    title: 'Home',
  },
  {
    path: '/profile',
    element: <ProfilePage />,
    title: 'profile',
  },
  {
    path: '/board',
    element: <BoardPage />,
    title: 'board',
  },
  {
    path: '/hello',
    element: <HelloPage />,
    title: 'hello',
  },
  {
    path: '/jsx',
    element: <JSXPage />,
    title: 'jsx문법',
  },
  {
    path: '/conditional',
    element: <ConditionalPage />,
    title: '조건부랜더링',
  },
  {
    path: '/bootstrap',
    element: <BootStrapPage />,
    title: '부트스트랩적용',
  },
  {
    path: '/props',
    element: <PropsPage />,
    title: '프롭스',
  },
  {
    path: '/usestate',
    element: <CounterPage />,
    title: 'useState-연습',
  },
  {
    path: '/useeffect',
    element: <UseEffectPage />,
    title: 'useEffect-연습',
  },
  {
    path: '/useref',
    element: <UseRef1Page />,
    title: 'useRef-1',
  },
  {
    path: '/useref2',
    element: <UseRef2Page />,
    title: 'useRef-2',
  },
  {
    path: '/axiosget',
    element: <AxiosGetPage />,
    title: 'axios-get',
  },
  {
    path: '/axiosclient',
    element: <AxiosClient />,
    title: 'axios-client',
  },
  {
    path: '/InPutPage',
    element: <InputPage />,
    title: '기본-input',
  },
  {
    path: '/Grade',
    element: <GradeInputPage />,
    title: '성적-input',
  },
  {
    path: '/Grade2',
    element: <GradeInputPage2 />,
    title: '성적-input(다중입력)',
  },
  {
    path: '/styled-css',
    element: <InlineStylePage />,
    title: '인라인스타일'

  },
  {
    path: '/use-css',
    element: <ClassNameUsePage />,
    title: 'use-css'
  },
  {
    path: '/style-css',
    element: <StyledComponentPage />,
    title: 'styled-components',
  },
  {
    path: '/contextnotuse',
    element: <ContextNotUsePage />,
    title: '컨텍스트api-사용안함',
  },
  {
    path: '/contextuse',
    element: <ContextUsedPage />,
    title: '컨텍스트api-사용',
  },
  {
    path: '/contextapply',
    element:(
    <CounterProvider>
      <div>머리말</div>
    <CounterContextPage />
      <div>꼬리말</div>
    </CounterProvider>
    ),
    title: '컨텍스트api-활용-카운터',
  },
]

export default routes
