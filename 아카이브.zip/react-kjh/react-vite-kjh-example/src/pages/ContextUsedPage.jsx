import React, { createContext, useContext,useState } from 'react'

const HelloContext = createContext('안녕하세요')

const ContextUsedPage = () => {
  const [value, setValue] = useState(true)
  return (
    <>
      <HelloContext.Provider value={value ? 'good' : 'bad'}>
        <GrandParent/>
        <button onClick={() => setValue(!value)}>Click Me!</button>
      </HelloContext.Provider>
    </>
  )
}

function GrandParent() {
  return <Parent />
}

function Parent() {
  return <Child />
}

function Child() { // 해당 컨텍스트의 value값을 가지고 온다
  const text = useContext(HelloContext)
  return <div>컨텍스트에서 받아온 데이타:{text}</div>

}

export default ContextUsedPage