import React, { Component } from 'react'
import "/src/assets/css/ClassUsePage.css"

export class ClassnameUsePage extends Component {
  render() {
    return (
      <div>
        <p className="title">안녕하세요</p>
      </div>
    )
  }
}

export default ClassnameUsePage
